# Auditoria: projeto original × versão atual

Cada achado abaixo foi **verificado executando o código original**, não apenas lendo. Os comandos estão na coluna "Como verificar" para que você consiga repetir e demonstrar.

## 1. Resumo em números

| Métrica | Original | Atual |
|---|---|---|
| Acesso à página interna sem login | **HTTP 200** (qualquer pessoa entra) | HTTP 302 → `/entrar/?next=/` |
| Método do formulário de login | `GET` (senha na URL), sem token CSRF | `POST` + token CSRF |
| Autenticação | nenhuma (a view só exibia HTML) | `authenticate()` + sessão + bloqueio de força bruta |
| `check --deploy` | **1 erro + 7 avisos** | **0 erros + 2 avisos** (deliberados) |
| Tabelas no banco | **0** (`db.sqlite3` com 0 bytes) | migrações versionadas (2 apps) |
| Testes automatizados | 0 (`tests.py` vazio) | **50**, rodam em ~0,5 s |
| Login em tela de 360 px | **estoura** (largura 400 px) | sem rolagem horizontal (também a 320 px) |
| Contraste (WCAG AA: texto ≥ 4,5:1; componentes ≥ 3:1) | **4 de 4 pares medidos reprovados** (2,49 a 3,91) | **17 de 17 aprovados** (texto: 5,5 a 14,4; componentes: ≥ 3,7) |
| Elementos "mortos" (sem função) | 3 (*Trabalhe conosco*, *Ajuda*, *Sair*) | 0 |
| Arquivos no pacote entregue | 6.271, dos quais **99,5% eram o `venv`** | **58** (sem `venv`, sem banco, sem caches) |
| `SECRET_KEY` | escrita no código | variável de ambiente; sem ela, o app recusa subir em produção |

## 2. Achados

### Críticos (segurança e funcionamento)

| # | Achado | Como verificar | Correção |
|---|---|---|---|
| C1 | **Não existe autenticação.** `pagina_login` só renderiza o HTML; `/barbearia/` abre para qualquer um. | `Client().get("/barbearia/").status_code` → `200` | `LoginRequiredMixin` nas páginas internas; login real com `LoginView` |
| C2 | **Formulário usa `method="get"`**: matrícula e senha vão na URL (`/barbearia/?matricula=…&senha=…`), ficando no histórico, nos logs do servidor e no cabeçalho `Referer`. Também não há token CSRF. | Ver o `<form>` renderizado e a ausência de `csrfmiddlewaretoken` | `method="post"` + `{% csrf_token %}` |
| C3 | **Banco vazio e sem migrações aplicadas.** O `db.sqlite3` tem 0 bytes; `showmigrations` mostra tudo desmarcado. Sessões, admin e usuários não funcionam. | `python manage.py showmigrations` | Migrações geradas e versionadas; `migrate` documentado no README |
| C4 | **Configuração insegura para produção**: `SECRET_KEY` no código, `DEBUG = True`, `ALLOWED_HOSTS = []`. `MAILERS` com backend de console gera **erro** em `--deploy`, mesmo sem o app enviar e-mail. | `python manage.py check --deploy` → 1 erro, 7 avisos | `settings.py` lê o ambiente, `DEBUG` desligado por padrão, cookies/HSTS/SSL em produção, `MAILERS` removido (o app não envia e-mail) |
| C5 | **Entrega com o `venv` dentro do zip**: 45,1 MB dos 45,3 MB (99,4%) e 6.237 dos 6.271 arquivos. O `pyvenv.cfg` grava o caminho do seu usuário do Windows. Sem `.gitignore`. | Listar o zip | `.gitignore` (venv, `.env`, `db.sqlite3`) e `requirements.txt` com teto de versão |

### Importantes (qualidade e experiência)

| # | Achado | Correção |
|---|---|---|
| I1 | `Sair (voltar ao login)` é só um link: nenhuma sessão é encerrada (e não havia sessão). | Logout real, só por `POST`, com mensagem de confirmação |
| I2 | **Elementos mortos**: botão *Trabalhe conosco* e link *Informações de Ajuda* (`href="#"`) não levam a lugar nenhum. | Formulário de candidatura completo; página de ajuda com conteúdo real |
| I3 | **Layout quebra no celular**: `form { width: 400px; height: 400px }`. A 360 px a página rola na horizontal (medido: 400 px de largura num viewport de 360 px); a altura fixa cortaria mensagens de erro. | Layout fluido com `grid`; sem larguras/alturas fixas |
| I4 | **Contraste insuficiente** (WCAG AA exige 4,5:1): botão verde com texto branco **2,99:1**; link azul sobre cinza **3,91:1**; rodapé **3,08:1**; vermelho puro sobre cinza **2,49:1**. | Paleta nova; os 17 pares texto/fundo e componente/fundo usados foram medidos |
| I5 | `autocomplete="off"` no campo de senha atrapalha gerenciadores de senha. | `autocomplete="current-password"` e `username` |
| I6 | Fonte `Roboto` declarada mas **nunca carregada**: cada máquina mostra uma fonte diferente. | Pilha de fontes do sistema (sem dependência externa) |
| I7 | Dois CSS com `* { margin:0; padding:0 }` e regras em tags soltas (`img`, `a`, `button`): conflitam se forem carregados juntos. | Um CSS com variáveis e classes (`.botao`, `.campo`, …) |
| I8 | Templates sem herança: `<head>` repetido em cada página. | `base.html` com blocos e componentes reutilizáveis |
| I9 | App chamado `projeto` e arquivos de *scaffold* vazios (`models.py`, `admin.py`, `tests.py`, `apps.py`). Nome não diz o que o app faz. | Apps `contas` e `barbearia`, com modelos, admin e testes reais |
| I10 | Sem tratamento de erros: nenhuma página 404/500 própria. | `404.html`, `500.html` e `403_csrf.html` |

### Pontos fortes do original (para você citar com segurança)

- Django 6.1: versão atual, com `CsrfViewMiddleware` e validadores de senha ligados.
- `LANGUAGE_CODE = "pt-br"` e `TIME_ZONE = "America/Recife"` corretos; uso de `{% static %}` e `{% url %}` (sem caminhos fixos).
- `<html lang>`, `<meta viewport>`, textos `alt` nas imagens e `<label for>` associado aos campos: boa base de acessibilidade.
- O ajuste de `mimetypes` para `.css` no Windows (mantido) mostra que você diagnosticou um problema real de ambiente.
- Imagens leves (a maior tem cerca de 170 KB).

## 3. O que as mudanças NÃO resolvem (seja franco na banca)

- **O bloqueio de login usa cache em memória**: serve para 1 processo. Em produção com vários *workers*, precisa de Redis/`DatabaseCache`.
- **O JavaScript não tem teste automatizado.** Foi verificado manualmente num navegador (Chromium): mostrar/ocultar senha, máscara de telefone e anti-duplo-clique.
- **Sem medição de cobertura de testes.** Os 50 testes cobrem os fluxos e as regras principais, mas não afirmo uma porcentagem.
- Visual verificado em **Chromium**; não foi testado em Safari, Firefox nem em dispositivos reais.
- **Não foi publicado em servidor real**; a seção 6 de `ARQUITETURA.md` lista o que mudaria.
- **Textos da página de ajuda** são uma proposta: ajuste para refletir como a barbearia realmente entrega matrículas e redefine senhas.
- **Sem agendamento, recuperação de senha por e-mail, 2FA, upload de currículo, Docker ou CI** (ver `ARQUITETURA.md`, seção 7).

## 4. Validação dos testes (teste de mutação manual)

Para provar que os testes **detectam** defeitos (e não só passam), sabotei o código de 7 formas e rodei a suíte:

| Sabotagem | Resultado da suíte |
|---|---|
| Remover `LoginRequiredMixin` da página interna | falha |
| Desligar o bloqueio de força bruta | falha |
| Aceitar logout por `GET` | falha |
| Mensagem de erro que revela se a matrícula existe | falha |
| Remover a regra de duplicidade de candidatura | falha |
| Afrouxar a CSP com `unsafe-inline` | falha |
| Liberar `next` para site externo (*open redirect*) | falha |

Na primeira rodada, a sabotagem da CSP **passou despercebida**. Descobri que meu teste checava só uma substring (`script-src 'self'`), que continua presente mesmo com `'unsafe-inline'` ao lado. Reforcei o teste para proibir `unsafe-inline` e `unsafe-eval`, e a sabotagem passou a ser detectada.
