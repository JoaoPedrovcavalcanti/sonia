# Arquitetura

> Os diagramas usam [Mermaid](https://mermaid.js.org/), que o GitHub e o VS Code (com extensão) renderizam. Em um leitor comum aparecem como código.

## 1. Visão geral

Aplicação **monolítica em Django**, com renderização de HTML no servidor. Dois apps com responsabilidades separadas:

- **`contas`**: quem é você (usuário, login, logout, proteção contra força bruta).
- **`barbearia`**: o que o site faz (página institucional e candidaturas).

```mermaid
flowchart LR
    N[Navegador] --> MW["Middlewares<br/>Security, CSP, Sessão, CSRF, Auth, Mensagens"]
    MW --> URL[sistema/urls.py]
    URL --> VC["contas.views<br/>Entrar, Sair, Ajuda"]
    URL --> VB["barbearia.views<br/>Inicio, Candidatura"]
    VC --> FC["contas.forms<br/>EntrarForm"]
    FC --> TH["contas.throttle<br/>contador no cache"]
    VB --> FB["barbearia.forms<br/>valida o formato"]
    VB --> SV["barbearia.services<br/>regras de negocio"]
    SV --> DB[("Models + SQLite")]
    FC --> DB
    VC --> TP[Templates + static]
    VB --> TP
```

## 2. Camadas e responsabilidades

Cada camada tem **um** trabalho. Isso torna o código fácil de testar e de explicar.

| Camada | Arquivo | Responsabilidade | Não faz |
|---|---|---|---|
| **View** | `views.py` | Receber a requisição, chamar form/serviço, escolher a resposta (redirecionar, renderizar) | Não contém regra de negócio |
| **Form** | `forms.py` | Validar o **formato** (e-mail válido, telefone com DDD, nome com 3+ letras) e normalizar (e-mail em minúsculas, telefone só com dígitos) | Não consulta o histórico de candidaturas |
| **Service** | `services.py` | Decidir **regras**: "uma pessoa não se candidata ao mesmo cargo 2× em 30 dias" | Não sabe nada de HTTP |
| **Model + banco** | `models.py` | Estrutura e **invariantes** (`CHECK consentimento = true`, índice de busca) | Não valida formulário |
| **Template** | `templates/` | Apresentação; escape automático de HTML | Não decide nada |

**Por que o serviço existe só em `barbearia`?** Porque lá existe uma regra de negócio. Em `contas` o Django já entrega a autenticação pronta (`LoginView`, `authenticate`), então criar uma camada extra seria burocracia.

## 3. Fluxos de dados

### 3.1 Login

```mermaid
sequenceDiagram
    actor U as Usuario
    participant V as EntrarView
    participant F as EntrarForm
    participant T as throttle (cache)
    participant A as authenticate()
    U->>V: POST /entrar/ (matricula, senha, token CSRF)
    V->>F: validar formulario
    F->>T: esta bloqueado? (matricula + IP)
    alt bloqueado
        F-->>V: erro "bloqueado"
        V-->>U: HTTP 429 + mensagem
    else liberado
        F->>A: authenticate(matricula, senha)
        alt credenciais corretas
            A-->>F: usuario
            F->>T: limpar contador
            V-->>U: 302 para a pagina pedida (cookie de sessao)
        else incorretas
            F->>T: registrar falha
            V-->>U: 200 + "Matricula ou senha incorretas"
        end
    end
```

### 3.2 Envio de candidatura

```mermaid
sequenceDiagram
    actor U as Usuario logado
    participant V as CandidaturaView
    participant F as CandidaturaForm
    participant S as services.registrar_candidatura
    participant D as Banco
    U->>V: POST /trabalhe-conosco/
    V->>F: validar formato e normalizar
    alt formato invalido
        F-->>U: 200 + erros nos campos
    else valido
        V->>S: registrar(dados)
        S->>D: ja existe (email + cargo) nos ultimos 30 dias?
        alt duplicada
            S-->>V: CandidaturaDuplicada
            V-->>U: 200 + erro no formulario
        else nova
            S->>D: INSERT (consentimento = true)
            V-->>U: 302 para / + mensagem de sucesso
        end
    end
```

O `302` depois do `POST` é o padrão **Post/Redirect/Get**: apertar F5 refaz um `GET`, não reenvia o formulário (há teste para isso).

## 4. Modelo de dados

```mermaid
erDiagram
    USUARIO ||--o{ CANDIDATURA : "enviada_por"
    USUARIO {
        bigint id PK
        string username "matricula, unica"
        string password "hash PBKDF2"
        bool is_staff
        bool is_active
    }
    CANDIDATURA {
        bigint id PK
        string nome
        string email
        string telefone "so digitos"
        string cargo
        string status
        bool consentimento "CHECK = true"
        datetime criada_em
        bigint enviada_por_id FK "SET NULL"
    }
```

Se o usuário for apagado, a candidatura **permanece** (`on_delete=SET_NULL`): o histórico de seleção não deve sumir junto com uma conta.

## 5. Decisões técnicas e justificativas

| # | Decisão | Por quê | Alternativa descartada |
|---|---|---|---|
| 1 | **Django com templates no servidor** | Duas telas e um formulário. Herda CSRF, escape de HTML e sessões prontos, com superfície de ataque pequena | SPA (React) + API: dobraria o código e criaria problemas novos (CORS, tokens) sem ganho |
| 2 | **Modelo `Usuario` próprio, antes da 1ª migração** | O Django recomenda; trocar depois, com dados, é muito trabalhoso. A matrícula vira o login | Usar `User` padrão: funcionaria, mas ficaria preso |
| 3 | **Serviço só onde há regra** | Separa decisão de HTTP e deixa a regra testável sem requisição | Clean Architecture completa (entidades, casos de uso, repositórios): excesso para 1 regra, e avaliadores atentos percebem |
| 4 | **Bloqueio por matrícula + IP, no cache** | Simples, sem tabela nova. A chave com IP impede que alguém tranque a conta de outra pessoa de fora; o bloqueio vale para matrículas inexistentes também, então não revela quais existem | `django-axes`: mais completo, mas é dependência extra para um bloqueio de ~40 linhas |
| 5 | **Mesma mensagem para matrícula inexistente e senha errada** | Impede descobrir matrículas válidas | Mensagens específicas (melhor UX, pior segurança) |
| 6 | **CSP estrita (`SECURE_CSP`) e zero código inline** | Mesmo que um HTML malicioso escape, o navegador não executa script injetado. Um teste garante que nenhum template volte a usar inline | Sem CSP |
| 7 | **Configuração por variável de ambiente, `DEBUG` desligado por padrão** | Esquecer a variável em produção **não** liga o debug; sem `SECRET_KEY` o app nem sobe | `DEBUG=True` e chave no código (era o estado original) |
| 8 | **Fontes do sistema** | Sem requisição externa (privacidade/LGPD, desempenho, abre offline) | Google Fonts |
| 9 | **Consentimento LGPD no formulário e no banco** | Coletamos dado pessoal (nome, e-mail, telefone). O `CHECK` garante que nenhum registro exista sem consentimento, mesmo gravado por fora da aplicação | Só validar no formulário |
| 10 | **Telefone armazenado só com dígitos** | Um formato canônico facilita busca e evita duplicatas "(81) 9…" × "819…" | Guardar o texto digitado |
| 11 | **Melhoria progressiva (JS opcional)** | O site inteiro funciona com JavaScript desligado (testado); o JS só adiciona conforto (mostrar senha, máscara, evitar duplo clique) | Depender de JS |

### SOLID, de forma honesta

SOLID descreve hierarquias de classes; este projeto tem poucas, então só alguns princípios têm onde aparecer:

- **S (responsabilidade única):** a tabela da seção 2: cada camada faz uma coisa.
- **O (aberto/fechado):** limites de login (`LOGIN_MAX_FALHAS`) e janela de duplicidade são configuráveis sem mexer na lógica. Um novo cargo é um novo valor em `Candidatura.Cargo`.
- **D (inversão de dependência):** a view depende da função `registrar_candidatura`, não de detalhes do ORM; trocar a regra não exige mexer na view.
- **L e I** não se aplicam de forma relevante sem hierarquias de classes ou interfaces. Forçá-los seria teatro.

## 6. Como levar para produção

| Item | Hoje | Em produção |
|---|---|---|
| Servidor | `runserver` (só desenvolvimento) | Gunicorn/uWSGI atrás de Nginx, com HTTPS |
| Banco | SQLite | PostgreSQL |
| Cache do bloqueio de login | `LocMem` (por processo) | Redis (compartilhado entre processos) |
| Arquivos estáticos | servidos pelo Django em `DEBUG` | `collectstatic` + Nginx ou WhiteNoise |
| Segredos | `.env` local | variáveis do provedor / gerenciador de segredos |
| IP do cliente | `REMOTE_ADDR` | Proxy repassando o IP real em `REMOTE_ADDR` |
| Logs | console | agregador (os logs já não contêm dado pessoal) |

Antes de publicar: `python manage.py check --deploy` com as variáveis de produção. Resultado atual: **0 erros e 2 avisos** (`HSTS_INCLUDE_SUBDOMAINS` e `HSTS_PRELOAD`), deixados de propósito, porque são decisões **difíceis de desfazer** que dependem do domínio real.

## 7. Evolução (o que NÃO foi implementado)

Em ordem de valor para uma barbearia real:

1. **Agendamento de horários** (modelos `Profissional`, `Servico`, `Agendamento`, com regra de conflito de horário no serviço).
2. Recuperação de senha por e-mail (requer configurar `MAILERS`).
3. Upload de currículo (exige validar tipo e tamanho do arquivo e guardar fora do diretório público).
4. Autenticação em dois fatores para a equipe.
5. Docker + integração contínua (rodar `test` e `check --deploy` a cada commit).
