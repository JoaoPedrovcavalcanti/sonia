# Roteiro de apresentação

> Regra de ouro: **só afirme o que você consegue mostrar rodando.** Cada ponto abaixo tem uma forma de provar ao vivo. A banca valoriza mais "veja isto funcionando" do que um adjetivo.

## 1. Abertura (30 segundos)

> "É um portal para uma barbearia, em Django. Tem login por matrícula, uma página institucional protegida e um formulário *Trabalhe conosco* com regras de negócio. O foco que eu dei foi **segurança, qualidade e testes**: comecei com uma auditoria do que estava quebrado e corrigi, e consigo provar cada correção."

## 2. Demonstração (5 a 6 minutos)

Prepare antes: `migrate`, `createsuperuser`, e crie **dois** usuários comuns no admin (ex.: matrículas `2026001` e `2026002`). Deixe o servidor rodando.

| Passo | O que fazer | O que dizer |
|---|---|---|
| 1 | Abra `/` sem estar logado | "O original abria esta página para qualquer pessoa. Agora redireciona para o login e lembra para onde eu ia (`?next=/`)." |
| 2 | Digite uma senha errada | "A mensagem é a mesma para matrícula inexistente e senha errada: assim ninguém descobre quais matrículas existem." |
| 3 | Erre 5 vezes e depois acerte a senha | "Bloqueado por 15 minutos, com HTTP 429. Mesmo com a senha certa. É a defesa contra força bruta." |
| 4 | Entre com um usuário válido (outra matrícula) | "O bloqueio é por matrícula **e** IP: não afeta outras pessoas." |
| 5 | Mostre a barra de endereço | "No original a senha ia na URL (`GET`). Agora é `POST` com token CSRF." |
| 6 | Navegue pela página; reduza a janela até ~360 px | "Layout responsivo; o original estourava na horizontal no celular." |
| 7 | *Trabalhe conosco*: envie vazio, depois com telefone inválido, depois correto | "Validação no servidor, mensagens claras, consentimento LGPD obrigatório." |
| 8 | Envie **a mesma candidatura de novo** | "Regra de negócio: mesmo e-mail e mesmo cargo em 30 dias é barrado. Está em `services.py`, separado da view." |
| 9 | Abra `/admin/` → Candidaturas | "Equipe filtra, busca e muda a situação em lote." |
| 10 | No terminal: `python manage.py test` | "50 testes em meio segundo." |
| 11 | (opcional, impressiona) Sabote algo: remova `LoginRequiredMixin` de `InicioView` e rode os testes | "Falha: os testes realmente protegem. (Desfaça depois.)" |

## 3. Pontos fortes (e como provar)

| Afirmação | Prova |
|---|---|
| "Corrigi falhas de segurança do original" | `docs/AUDITORIA.md`; no original, `Client().get('/barbearia/')` → `200` |
| "Sem segredo no código" | abrir `settings.py`; rodar sem `DJANGO_SECRET_KEY` e `DEBUG=0` (o app recusa subir) |
| "Configuração pronta para produção" | `python manage.py check --deploy`: 0 erros, 2 avisos deliberados (original: 1 erro + 7 avisos) |
| "Testes que protegem de verdade" | a tabela de sabotagens da seção 4 de `AUDITORIA.md` |
| "Acessível" | navegar só com `Tab`; o *skip link* ("Pular para o conteúdo") aparece no primeiro `Tab` |
| "Funciona sem JavaScript" | desativar o JS nas ferramentas do navegador e repetir o login |

## 4. Perguntas que a banca pode fazer (e respostas)

**Por que Django e não Flask ou Node?**
Para autenticação, sessões, proteção CSRF, admin e ORM, o Django já traz tudo testado. Eu não precisaria escrever (e errar) segurança do zero. Para duas telas e um formulário, uma SPA seria mais código e mais superfície de ataque.

**O que é CSRF e como você se protege?**
É um ataque em que outro site faz o navegador do usuário (já logado) enviar uma requisição sem que ele perceba. O Django coloca um token secreto em cada formulário `POST` e rejeita requisições sem ele. Está em `{% csrf_token %}`, e há um teste que confirma o `403`.

**Por que o login é POST e não GET?**
No `GET`, os dados vão na URL e ficam no histórico do navegador, nos logs do servidor e no cabeçalho `Referer`. Foi o primeiro problema que encontrei no projeto original.

**O que acontece se eu digitar a matrícula errada? E se digitar a senha errada?**
A mesma mensagem nos dois casos: "Matrícula ou senha incorretas". Se fossem diferentes, um atacante descobriria matrículas válidas (*enumeração de usuários*).

**Como funciona o bloqueio? Ele tem limitações?**
Conta falhas por matrícula + IP no cache; 5 falhas bloqueiam por 15 min. Limitações: o cache é em memória (1 processo), então em produção com vários *workers* eu usaria Redis; e atrás de proxy o IP real depende da configuração do proxy.

**Por que um modelo de usuário próprio se só usa matrícula e senha?**
O Django recomenda definir antes da primeira migração, porque trocar depois, com dados, é difícil. Hoje o modelo é quase igual ao padrão, mas já posso acrescentar cargo ou unidade sem dor.

**Você usou Clean Architecture? Onde estão as camadas?**
Usei separação de responsabilidades onde ela paga o custo: *view* orquestra, *form* valida formato, *service* decide regras, *banco* garante invariantes. Uma Clean Architecture completa (entidades, casos de uso, repositórios) seria excesso para uma regra de negócio. Escolhi não fazer e posso justificar.

**Por que a regra de duplicidade está em `services.py` e não na view?**
Para testar a regra sem simular uma requisição HTTP, e para que ela valha se um dia houver outra entrada (API, importação).

**O que é a CSP e por que não tem `<script>` inline?**
*Content-Security-Policy* diz ao navegador que só execute scripts e estilos do próprio site. Se alguém conseguisse injetar HTML malicioso, o navegador não o executaria. Por isso os templates não têm código inline, e um teste garante isso.

**Por que SQLite?**
É suficiente para desenvolvimento e demonstração e não exige instalar nada. Para produção com vários usuários simultâneos, eu migraria para PostgreSQL (o Django troca o banco só mudando a configuração).

**Por que o telefone é guardado só com dígitos?**
Um formato único evita duplicatas como "(81) 9…" e "819…" e facilita busca. A máscara é só de exibição.

**Como você trata dados pessoais (LGPD)?**
O formulário exige consentimento e o banco tem um `CHECK` que impede registros sem ele; os logs nunca contêm nome, e-mail, telefone ou senha (há testes). Não sou advogado e não afirmo conformidade total, mas apliquei os cuidados técnicos básicos.

**O que falta?**
(Responda com confiança, é um ponto forte saber isso.) Agendamento de horários, recuperação de senha por e-mail, 2FA, Docker/CI, e testes automatizados para o JavaScript. Está listado em `docs/ARQUITETURA.md`, seção 7.

## 5. Se pedirem para mudar algo ao vivo

| Pedido | Onde mexer |
|---|---|
| "Bloqueie com 3 tentativas" | `LOGIN_MAX_FALHAS = 3` em `settings.py` (a página de ajuda se atualiza sozinha) |
| "Bloqueio de 30 minutos" | `LOGIN_BLOQUEIO_SEGUNDOS = 30 * 60` |
| "Janela de duplicidade de 15 dias" | `JANELA_DUPLICIDADE` em `barbearia/services.py` |
| "Adicione o cargo *Gerente*" | uma linha em `Candidatura.Cargo` (`models.py`), depois `makemigrations` e `migrate` |
| "Exija sessão mais curta" | `SESSION_COOKIE_AGE` em `settings.py` |
| "Nova página protegida" | *view* com `LoginRequiredMixin` + rota em `urls.py` + template estendendo `base.html` |

## 6. Fraquezas para admitir **antes** que perguntem

1. O bloqueio de login em memória não escala para vários processos.
2. Não rodei em servidor real; testei localmente e no Chromium.
3. O JavaScript é pequeno e foi verificado manualmente, sem teste automatizado.
4. Os textos da página de ajuda são uma proposta minha para o fluxo de matrícula e senha.

## 7. Checklist antes de entregar

- [ ] `python manage.py test` passa na **sua** máquina (Windows).
- [ ] `python manage.py migrate` roda em um banco novo sem erro.
- [ ] Você consegue abrir **cada arquivo** do projeto e explicar o que ele faz, sem consultar este roteiro.
- [ ] Rode a demonstração da seção 2 duas vezes, sem olhar as anotações.
- [ ] Confira o **nome e o curso** em todos os arquivos que vai entregar.
- [ ] Verifique a política da sua instituição sobre uso de ferramentas de IA e cite o uso se for exigido. A banca pode pedir que você altere código ao vivo (seção 5).
- [ ] Entregue **sem** `venv`, `.env` e `db.sqlite3` (o `.gitignore` já cuida disso no Git).
