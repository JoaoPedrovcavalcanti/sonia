from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import FormView, TemplateView

from . import services
from .forms import CandidaturaForm


class InicioView(LoginRequiredMixin, TemplateView):
    """Página institucional. Exige login (o original deixava qualquer um entrar)."""

    template_name = "barbearia/inicio.html"


class CandidaturaView(LoginRequiredMixin, FormView):
    template_name = "barbearia/candidatura.html"
    form_class = CandidaturaForm
    success_url = reverse_lazy("barbearia:inicio")

    def form_valid(self, form):
        dados = {k: form.cleaned_data[k] for k in ("nome", "email", "telefone", "cargo", "mensagem")}
        try:
            services.registrar_candidatura(**dados, enviada_por=self.request.user)
        except services.CandidaturaDuplicada as erro:
            form.add_error(None, str(erro))
            return self.form_invalid(form)

        # Padrão Post/Redirect/Get: recarregar a página não reenvia o formulário.
        messages.success(self.request, "Candidatura enviada! Entraremos em contato pelo e-mail ou telefone informado.")
        return super().form_valid(form)
