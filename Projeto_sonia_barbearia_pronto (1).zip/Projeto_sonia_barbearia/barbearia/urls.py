from django.urls import path

from . import views

app_name = "barbearia"

urlpatterns = [
    path("", views.InicioView.as_view(), name="inicio"),
    path("trabalhe-conosco/", views.CandidaturaView.as_view(), name="candidatura"),
]
