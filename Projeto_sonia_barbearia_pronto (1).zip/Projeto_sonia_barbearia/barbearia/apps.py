from django.apps import AppConfig


class BarbeariaConfig(AppConfig):
    name = "barbearia"
    verbose_name = "Barbearia"
