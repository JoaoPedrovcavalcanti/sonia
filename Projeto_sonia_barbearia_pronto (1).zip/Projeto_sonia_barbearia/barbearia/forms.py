import re

from django import forms

from .models import Candidatura


class CandidaturaForm(forms.ModelForm):
    """Valida o FORMATO dos dados. A regra de negócio (duplicidade) fica em services.py."""

    # Campo declarado aqui para aceitar a máscara "(81) 99999-9999" (o campo do
    # modelo guarda só dígitos, com max_length=11).
    telefone = forms.CharField(
        label="Telefone com DDD",
        max_length=20,
        widget=forms.TextInput(
            attrs={"inputmode": "tel", "autocomplete": "tel-national", "placeholder": "(81) 99999-9999"}
        ),
    )
    aceite_lgpd = forms.BooleanField(
        label="Concordo que a Barbearia use meus dados somente para o processo seletivo.",
        error_messages={"required": "Para enviar, é preciso concordar com o uso dos dados."},
    )

    class Meta:
        model = Candidatura
        fields = ("nome", "email", "telefone", "cargo", "mensagem")
        widgets = {
            "nome": forms.TextInput(attrs={"autocomplete": "name"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email"}),
            "mensagem": forms.Textarea(attrs={"rows": 4}),
        }
        help_texts = {
            "mensagem": "Opcional. Conte sua experiência e disponibilidade (até 1000 caracteres).",
        }

    def clean_nome(self):
        nome = " ".join(self.cleaned_data["nome"].split())  # remove espaços duplicados
        if len(nome) < 3:
            raise forms.ValidationError("Informe seu nome completo.")
        return nome

    def clean_email(self):
        return self.cleaned_data["email"].strip().lower()

    def clean_telefone(self):
        digitos = re.sub(r"\D", "", self.cleaned_data["telefone"])
        if len(digitos) not in (10, 11):
            raise forms.ValidationError("Informe o DDD e o número (10 ou 11 dígitos).")
        if digitos[0] == "0" or digitos[1] == "0":
            raise forms.ValidationError("DDD inválido.")
        if len(digitos) == 11 and digitos[2] != "9":
            raise forms.ValidationError("Celulares têm 9 dígitos e começam com 9.")
        return digitos
