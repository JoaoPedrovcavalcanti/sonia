from django.contrib import admin

from .models import Candidatura


@admin.register(Candidatura)
class CandidaturaAdmin(admin.ModelAdmin):
    list_display = ("nome", "cargo", "email", "telefone", "status", "criada_em")
    list_filter = ("status", "cargo", "criada_em")
    list_editable = ("status",)
    search_fields = ("nome", "email", "telefone")
    date_hierarchy = "criada_em"
    readonly_fields = ("criada_em", "enviada_por", "consentimento")
    fieldsets = (
        ("Candidato", {"fields": ("nome", "email", "telefone")}),
        ("Candidatura", {"fields": ("cargo", "mensagem", "status")}),
        ("Registro", {"fields": ("criada_em", "enviada_por", "consentimento")}),
    )
