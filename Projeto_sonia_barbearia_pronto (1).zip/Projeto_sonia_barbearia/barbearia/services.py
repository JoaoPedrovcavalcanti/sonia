"""Regras de negócio das candidaturas.

Camada de serviço: as views só orquestram (receber -> chamar serviço ->
responder) e os formulários só validam formato. Quem decide o que é permitido
fica aqui, em funções simples e fáceis de testar.
"""

import logging
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from .models import Candidatura

logger = logging.getLogger("barbearia")

# Uma pessoa não pode se candidatar ao MESMO cargo mais de uma vez neste prazo.
JANELA_DUPLICIDADE = timedelta(days=30)


class CandidaturaDuplicada(Exception):
    """Já existe candidatura recente do mesmo e-mail para o mesmo cargo."""


@transaction.atomic
def registrar_candidatura(*, nome, email, telefone, cargo, mensagem="", enviada_por=None) -> Candidatura:
    desde = timezone.now() - JANELA_DUPLICIDADE
    if Candidatura.objects.filter(email__iexact=email, cargo=cargo, criada_em__gte=desde).exists():
        raise CandidaturaDuplicada(
            f"Já recebemos uma candidatura sua para este cargo nos últimos {JANELA_DUPLICIDADE.days} dias."
        )

    candidatura = Candidatura.objects.create(
        nome=nome,
        email=email,
        telefone=telefone,
        cargo=cargo,
        mensagem=mensagem,
        consentimento=True,
        enviada_por=enviada_por,
    )
    # Log sem dados pessoais: só o identificador.
    logger.info("Candidatura registrada id=%s cargo=%s", candidatura.pk, cargo)
    return candidatura
