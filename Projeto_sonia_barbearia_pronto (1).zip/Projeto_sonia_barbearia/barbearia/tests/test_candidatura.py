from datetime import timedelta

from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone

from barbearia import services
from barbearia.models import Candidatura
from contas.models import Usuario
from sistema.utils_teste import BaseTestCase

DADOS_VALIDOS = {
    "nome": "João da Silva",
    "email": "joao@exemplo.com",
    "telefone": "(81) 99999-8888",
    "cargo": "barbeiro",
    "mensagem": "Tenho 5 anos de experiência.",
    "aceite_lgpd": "on",
}


class AcessoTests(BaseTestCase):
    """O original deixava qualquer pessoa abrir a página interna sem login."""

    def test_anonimo_e_enviado_ao_login_com_next(self):
        for nome in ("barbearia:inicio", "barbearia:candidatura"):
            with self.subTest(rota=nome):
                url = reverse(nome)
                resposta = self.client.get(url)
                self.assertRedirects(resposta, f"{reverse('contas:entrar')}?next={url}")

    def test_anonimo_nao_consegue_enviar_candidatura(self):
        self.client.post(reverse("barbearia:candidatura"), DADOS_VALIDOS)
        self.assertEqual(Candidatura.objects.count(), 0)


class PaginasTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.usuario = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.client.force_login(self.usuario)

    def test_inicio_mostra_conteudo_institucional(self):
        resposta = self.client.get(reverse("barbearia:inicio"))
        self.assertContains(resposta, "Sobre a Barbearia")
        self.assertContains(resposta, "Proporcionar auto-estima e qualidade de vida aos clientes.")
        self.assertContains(resposta, "Profissionais qualificados")
        self.assertContains(resposta, reverse("barbearia:candidatura"))  # o botão agora leva a algum lugar

    def test_cabecalho_mostra_matricula_e_logout_por_post(self):
        resposta = self.client.get(reverse("barbearia:inicio"))
        self.assertContains(resposta, "2026001")
        self.assertContains(resposta, f'action="{reverse("contas:sair")}"')

    def test_pagina_500_renderiza_sem_contexto(self):
        # O Django renderiza o 500.html SEM request/user: ele precisa ser autônomo.
        from django.template.loader import render_to_string

        html = render_to_string("500.html")
        self.assertIn("Algo deu errado", html)

    def test_pagina_404_personalizada(self):
        resposta = self.client.get("/rota-que-nao-existe/")
        self.assertContains(resposta, "Página não encontrada", status_code=404)


class CandidaturaFormTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.usuario = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.client.force_login(self.usuario)
        self.url = reverse("barbearia:candidatura")

    def _enviar(self, **alteracoes):
        dados = {**DADOS_VALIDOS, **alteracoes}
        dados = {k: v for k, v in dados.items() if v is not None}
        return self.client.post(self.url, dados)

    def test_envio_valido_cria_candidatura_normalizada(self):
        resposta = self._enviar(email="  JOAO@Exemplo.COM ", nome="  João   da  Silva ")
        self.assertRedirects(resposta, reverse("barbearia:inicio"))
        c = Candidatura.objects.get()
        self.assertEqual(c.email, "joao@exemplo.com")
        self.assertEqual(c.nome, "João da Silva")
        self.assertEqual(c.telefone, "81999998888")  # só dígitos
        self.assertTrue(c.consentimento)
        self.assertEqual(c.status, Candidatura.Status.NOVA)
        self.assertEqual(c.enviada_por, self.usuario)

    def test_mostra_mensagem_de_sucesso(self):
        resposta = self.client.post(self.url, DADOS_VALIDOS, follow=True)
        self.assertContains(resposta, "Candidatura enviada!")

    def test_recarregar_a_pagina_apos_enviar_nao_duplica(self):
        resposta = self.client.post(self.url, DADOS_VALIDOS)
        self.client.get(resposta["Location"])  # Post/Redirect/Get: F5 faz GET, não POST
        self.assertEqual(Candidatura.objects.count(), 1)

    def test_exige_consentimento(self):
        resposta = self._enviar(aceite_lgpd=None)
        self.assertContains(resposta, "concordar com o uso dos dados")
        self.assertEqual(Candidatura.objects.count(), 0)

    def test_nome_muito_curto(self):
        self.assertContains(self._enviar(nome="Jo"), "Informe seu nome completo.")

    def test_email_invalido(self):
        resposta = self._enviar(email="isso-nao-e-email")
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(Candidatura.objects.count(), 0)

    def test_telefones_invalidos(self):
        casos = {
            "123": "10 ou 11 dígitos",
            "(08) 99999-8888": "DDD inválido",
            "(81) 89999-8888": "começam com 9",
        }
        for telefone, trecho in casos.items():
            with self.subTest(telefone=telefone):
                self.assertContains(self._enviar(telefone=telefone), trecho)
        self.assertEqual(Candidatura.objects.count(), 0)

    def test_telefone_fixo_de_10_digitos_e_aceito(self):
        self._enviar(telefone="(81) 3333-4444")
        self.assertEqual(Candidatura.objects.get().telefone, "8133334444")

    def test_cargo_fora_da_lista_e_rejeitado(self):
        self._enviar(cargo="presidente")
        self.assertEqual(Candidatura.objects.count(), 0)

    def test_mensagem_acima_de_1000_caracteres_e_rejeitada(self):
        self._enviar(mensagem="x" * 1001)
        self.assertEqual(Candidatura.objects.count(), 0)


class RegraDeDuplicidadeTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.base = dict(nome="João da Silva", email="joao@exemplo.com", telefone="81999998888", cargo="barbeiro")

    def test_mesmo_email_e_cargo_dentro_de_30_dias_e_barrado(self):
        services.registrar_candidatura(**self.base)
        with self.assertRaises(services.CandidaturaDuplicada):
            services.registrar_candidatura(**{**self.base, "email": "JOAO@exemplo.com"})  # maiúsculas não burlam
        self.assertEqual(Candidatura.objects.count(), 1)

    def test_outro_cargo_e_permitido(self):
        services.registrar_candidatura(**self.base)
        services.registrar_candidatura(**{**self.base, "cargo": "recepcao"})
        self.assertEqual(Candidatura.objects.count(), 2)

    def test_apos_30_dias_pode_se_candidatar_de_novo(self):
        antiga = services.registrar_candidatura(**self.base)
        Candidatura.objects.filter(pk=antiga.pk).update(criada_em=timezone.now() - timedelta(days=31))
        services.registrar_candidatura(**self.base)
        self.assertEqual(Candidatura.objects.count(), 2)

    def test_duplicada_aparece_como_erro_no_formulario(self):
        usuario = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.client.force_login(usuario)
        services.registrar_candidatura(**self.base)
        resposta = self.client.post(reverse("barbearia:candidatura"), {**DADOS_VALIDOS})
        self.assertContains(resposta, "Já recebemos uma candidatura sua para este cargo")
        self.assertEqual(Candidatura.objects.count(), 1)

    def test_log_da_candidatura_nao_contem_dados_pessoais(self):
        with self.assertLogs("barbearia", level="INFO") as logs:
            services.registrar_candidatura(**self.base)
        texto = " ".join(logs.output)
        for pii in ("João", "joao@exemplo.com", "81999998888"):
            self.assertNotIn(pii, texto)


class RestricaoNoBancoTests(BaseTestCase):
    def test_banco_recusa_candidatura_sem_consentimento(self):
        # Mesmo contornando formulário e serviço, o CHECK do banco impede.
        with self.assertRaises(IntegrityError), transaction.atomic():
            Candidatura.objects.create(
                nome="X Y Z", email="x@y.com", telefone="81999998888", cargo="outro", consentimento=False
            )


class AdminCandidaturaTests(BaseTestCase):
    def test_admin_escapa_html_malicioso(self):
        services.registrar_candidatura(
            nome='<script>alert("xss")</script>', email="a@b.com", telefone="81999998888", cargo="outro"
        )
        admin = Usuario.objects.create_superuser("admin", password=self.SENHA)
        self.client.force_login(admin)
        resposta = self.client.get(reverse("admin:barbearia_candidatura_changelist"))
        self.assertNotContains(resposta, '<script>alert("xss")</script>')
        self.assertContains(resposta, "&lt;script&gt;")
