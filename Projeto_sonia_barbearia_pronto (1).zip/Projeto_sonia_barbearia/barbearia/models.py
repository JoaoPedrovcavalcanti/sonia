from django.conf import settings
from django.core.validators import RegexValidator
from django.db import models


class Candidatura(models.Model):
    """Candidatura enviada pelo formulário "Trabalhe conosco"."""

    class Cargo(models.TextChoices):
        BARBEIRO = "barbeiro", "Barbeiro(a)"
        AUXILIAR = "auxiliar", "Auxiliar de barbearia"
        RECEPCAO = "recepcao", "Recepção e atendimento"
        OUTRO = "outro", "Outro"

    class Status(models.TextChoices):
        NOVA = "nova", "Nova"
        EM_ANALISE = "em_analise", "Em análise"
        APROVADA = "aprovada", "Aprovada"
        DESCARTADA = "descartada", "Descartada"

    nome = models.CharField("nome completo", max_length=120)
    email = models.EmailField("e-mail")
    # Guardado só com dígitos (DDD + número). A máscara é só de exibição.
    telefone = models.CharField(
        "telefone",
        max_length=11,
        validators=[RegexValidator(r"^[1-9][1-9]\d{8,9}$", "Informe DDD e número válidos.")],
    )
    cargo = models.CharField("cargo de interesse", max_length=20, choices=Cargo.choices)
    mensagem = models.TextField("mensagem", max_length=1000, blank=True)
    status = models.CharField("situação", max_length=20, choices=Status.choices, default=Status.NOVA)
    # Registro de que a pessoa aceitou o uso dos dados (LGPD, art. 7º, I).
    consentimento = models.BooleanField("consentimento LGPD", default=False, editable=False)
    enviada_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name="enviada por",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="candidaturas",
    )
    criada_em = models.DateTimeField("enviada em", auto_now_add=True)

    class Meta:
        verbose_name = "candidatura"
        verbose_name_plural = "candidaturas"
        ordering = ["-criada_em"]
        indexes = [models.Index(fields=["email", "cargo", "criada_em"], name="cand_email_cargo_data_idx")]
        constraints = [
            # Garantia no BANCO: nenhuma candidatura existe sem consentimento,
            # mesmo que alguém grave por fora da aplicação.
            models.CheckConstraint(
                condition=models.Q(consentimento=True),
                name="cand_exige_consentimento",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.nome} — {self.get_cargo_display()}"
