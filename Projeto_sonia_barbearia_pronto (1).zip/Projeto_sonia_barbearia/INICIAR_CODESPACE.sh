#!/bin/bash
# Rode no terminal do Codespace:   bash INICIAR_CODESPACE.sh
set -e
cd "$(dirname "$0")"

export DJANGO_DEBUG=1
export DJANGO_ALLOWED_HOSTS=".app.github.dev,localhost,127.0.0.1"
export DJANGO_CSRF_TRUSTED_ORIGINS="https://*.app.github.dev"

echo ">> Instalando Django..."
pip install -r requirements.txt

echo ">> Criando o banco de dados..."
python manage.py migrate

if [ "$(python manage.py shell -c 'from django.contrib.auth import get_user_model as g; print(g().objects.count())' | tail -1)" = "0" ]; then
  echo ">> Crie o seu usuario (Matricula, E-mail pode ficar vazio, Senha):"
  python manage.py createsuperuser
fi

echo ">> Iniciando o site. Clique em 'Abrir no navegador' quando aparecer o aviso."
python manage.py runserver 0.0.0.0:8000
