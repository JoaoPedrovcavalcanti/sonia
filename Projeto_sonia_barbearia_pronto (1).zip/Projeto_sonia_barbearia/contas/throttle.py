"""Proteção contra força bruta no login.

Regra: após `LOGIN_MAX_FALHAS` tentativas erradas para a MESMA combinação
(matrícula + IP), o login fica bloqueado por `LOGIN_BLOQUEIO_SEGUNDOS`.

Decisões de projeto:
- A chave inclui o IP: um atacante não consegue trancar a conta de outra
  pessoa a partir de outro endereço.
- O bloqueio vale para qualquer matrícula digitada, exista ou não: a resposta
  não revela quais matrículas são válidas (sem enumeração de usuários).
- A chave é um hash: matrícula e IP não ficam legíveis no cache.
"""

import hashlib

from django.conf import settings
from django.core.cache import cache


def ip_do_cliente(request) -> str:
    """IP de quem fez a requisição.

    Usa REMOTE_ADDR de propósito: o cabeçalho X-Forwarded-For pode ser forjado
    pelo cliente. Atrás de proxy reverso, configure o proxy/servidor para
    repassar o IP real em REMOTE_ADDR.
    """
    return request.META.get("REMOTE_ADDR", "")


def hash_matricula(matricula: str) -> str:
    """Identificador curto e não reversível, seguro para logs."""
    return hashlib.sha256(matricula.strip().lower().encode()).hexdigest()[:10]


def _chave(matricula: str, ip: str) -> str:
    bruto = f"{matricula.strip().lower()}|{ip}"
    return "login-falhas:" + hashlib.sha256(bruto.encode()).hexdigest()


def bloqueado(matricula: str, ip: str) -> bool:
    return cache.get(_chave(matricula, ip), 0) >= settings.LOGIN_MAX_FALHAS


def registrar_falha(matricula: str, ip: str) -> int:
    """Soma uma falha e devolve o total acumulado."""
    chave = _chave(matricula, ip)
    cache.add(chave, 0, settings.LOGIN_BLOQUEIO_SEGUNDOS)  # cria só se não existir
    try:
        return cache.incr(chave)
    except ValueError:  # a chave expirou entre o add e o incr
        cache.set(chave, 1, settings.LOGIN_BLOQUEIO_SEGUNDOS)
        return 1


def limpar(matricula: str, ip: str) -> None:
    cache.delete(_chave(matricula, ip))
