import re

from django.urls import reverse

from contas.models import Usuario
from sistema.utils_teste import BaseTestCase


class CabecalhosDeSegurancaTests(BaseTestCase):
    def test_cabecalhos_presentes(self):
        resposta = self.client.get(reverse("contas:entrar"))
        csp = resposta["Content-Security-Policy"]
        self.assertIn("default-src 'self'", csp)
        self.assertIn("script-src 'self'", csp)
        self.assertIn("frame-ancestors 'none'", csp)
        # A política só vale se for ESTRITA: nada de código inline ou eval.
        self.assertNotIn("unsafe-inline", csp)
        self.assertNotIn("unsafe-eval", csp)
        self.assertEqual(resposta["X-Frame-Options"], "DENY")
        self.assertEqual(resposta["X-Content-Type-Options"], "nosniff")
        self.assertEqual(resposta["Referrer-Policy"], "same-origin")


class CspCompativelComOsTemplatesTests(BaseTestCase):
    """A CSP é estrita (sem 'unsafe-inline'). Estes testes garantem que nenhum
    template volte a usar código inline, o que quebraria a página em produção."""

    def setUp(self):
        super().setUp()
        self.client.force_login(Usuario.objects.create_user("2026001", password=self.SENHA))

    def test_nenhum_template_usa_script_ou_estilo_inline(self):
        rotas = ["contas:entrar", "contas:ajuda", "barbearia:inicio", "barbearia:candidatura"]
        for nome in rotas:
            with self.subTest(rota=nome):
                if nome == "contas:entrar":
                    self.client.logout()  # a tela de login só aparece para anônimos
                html = self.client.get(reverse(nome), follow=True).content.decode()
                scripts = re.findall(r"<script\b[^>]*>", html)
                self.assertTrue(all("src=" in s for s in scripts), f"script inline em {nome}")
                self.assertNotRegex(html, r"\sstyle=", f"style inline em {nome}")
                self.assertNotRegex(html, r"\son(click|submit|load)=", f"handler inline em {nome}")
