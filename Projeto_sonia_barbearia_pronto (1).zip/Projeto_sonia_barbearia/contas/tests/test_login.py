from django.conf import settings
from django.urls import reverse

from contas.models import Usuario
from sistema.utils_teste import BaseTestCase


class LoginTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse("contas:entrar")
        self.usuario = Usuario.objects.create_user("2026001", password=self.SENHA)

    def _post(self, matricula="2026001", senha=None, **extra):
        return self.client.post(self.url, {"username": matricula, "password": senha or self.SENHA, **extra})

    # --- o que estava quebrado no original -------------------------------
    def test_formulario_usa_post_com_csrf(self):
        resposta = self.client.get(self.url)
        self.assertContains(resposta, 'method="post"')
        self.assertContains(resposta, "csrfmiddlewaretoken")

    def test_login_por_get_nao_autentica_e_senha_nao_vale_na_url(self):
        resposta = self.client.get(self.url, {"username": "2026001", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_post_sem_csrf_e_rejeitado(self):
        from django.test import Client

        cliente = Client(enforce_csrf_checks=True)
        resposta = cliente.post(self.url, {"username": "2026001", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 403)
        self.assertContains(resposta, "Não foi possível validar o envio", status_code=403)

    # --- fluxo normal -----------------------------------------------------
    def test_login_correto_redireciona_para_inicio(self):
        resposta = self._post()
        self.assertRedirects(resposta, reverse("barbearia:inicio"))
        self.assertEqual(int(self.client.session["_auth_user_id"]), self.usuario.pk)

    def test_senha_incorreta_nao_autentica(self):
        resposta = self._post(senha="errada")
        self.assertEqual(resposta.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_mensagem_de_erro_e_igual_para_matricula_inexistente_e_senha_errada(self):
        # Se as mensagens fossem diferentes, um atacante descobriria matrículas válidas.
        a = self._post(matricula="9999999", senha="qualquer").content.decode()
        b = self._post(matricula="2026001", senha="errada").content.decode()
        msg = "Matrícula ou senha incorretas."
        self.assertIn(msg, a)
        self.assertIn(msg, b)

    def test_usuario_inativo_nao_entra(self):
        self.usuario.is_active = False
        self.usuario.save()
        self._post()
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_usuario_ja_logado_e_redirecionado_ao_abrir_o_login(self):
        self.client.force_login(self.usuario)
        self.assertRedirects(self.client.get(self.url), reverse("barbearia:inicio"))

    # --- redirecionamento seguro (open redirect) ---------------------------
    def test_next_interno_e_respeitado(self):
        destino = reverse("barbearia:candidatura")
        self.assertRedirects(self._post(next=destino), destino)

    def test_next_externo_e_ignorado(self):
        for malicioso in ("https://evil.example/", "//evil.example/", "javascript:alert(1)"):
            with self.subTest(next=malicioso):
                self.client.logout()
                resposta = self._post(next=malicioso)
                self.assertRedirects(resposta, reverse("barbearia:inicio"))


class LogoutTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.usuario = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.client.force_login(self.usuario)

    def test_logout_por_get_e_recusado(self):
        resposta = self.client.get(reverse("contas:sair"))
        self.assertEqual(resposta.status_code, 405)
        self.assertIn("_auth_user_id", self.client.session)  # continua logado

    def test_logout_por_post_encerra_sessao_e_avisa(self):
        resposta = self.client.post(reverse("contas:sair"), follow=True)
        self.assertRedirects(resposta, reverse("contas:entrar"))
        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertContains(resposta, "Você saiu do sistema com segurança.")


class BloqueioForcaBrutaTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.url = reverse("contas:entrar")
        Usuario.objects.create_user("2026001", password=self.SENHA)
        Usuario.objects.create_user("2026002", password=self.SENHA)

    def _falhar(self, vezes, matricula="2026001", **extra):
        for _ in range(vezes):
            self.client.post(self.url, {"username": matricula, "password": "errada"}, **extra)

    def test_bloqueia_apos_o_limite_mesmo_com_senha_correta(self):
        self._falhar(settings.LOGIN_MAX_FALHAS)
        resposta = self.client.post(self.url, {"username": "2026001", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 429)
        self.assertContains(resposta, "Muitas tentativas", status_code=429)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_nao_bloqueia_antes_do_limite(self):
        self._falhar(settings.LOGIN_MAX_FALHAS - 1)
        resposta = self.client.post(self.url, {"username": "2026001", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 302)

    def test_login_bem_sucedido_zera_o_contador(self):
        self._falhar(settings.LOGIN_MAX_FALHAS - 1)
        self.client.post(self.url, {"username": "2026001", "password": self.SENHA})
        self.client.logout()
        self._falhar(settings.LOGIN_MAX_FALHAS - 1)  # recomeça do zero: ainda não bloqueia
        resposta = self.client.post(self.url, {"username": "2026001", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 302)

    def test_bloqueio_nao_afeta_outra_matricula(self):
        self._falhar(settings.LOGIN_MAX_FALHAS, matricula="2026001")
        resposta = self.client.post(self.url, {"username": "2026002", "password": self.SENHA})
        self.assertEqual(resposta.status_code, 302)

    def test_bloqueio_nao_afeta_outro_ip(self):
        # Quem erra a senha de outra pessoa não consegue trancá-la fora de casa.
        self._falhar(settings.LOGIN_MAX_FALHAS, REMOTE_ADDR="10.0.0.99")
        resposta = self.client.post(self.url, {"username": "2026001", "password": self.SENHA}, REMOTE_ADDR="10.0.0.1")
        self.assertEqual(resposta.status_code, 302)

    def test_matricula_inexistente_tambem_e_bloqueada_sem_revelar_nada(self):
        self._falhar(settings.LOGIN_MAX_FALHAS, matricula="fantasma")
        resposta = self.client.post(self.url, {"username": "fantasma", "password": "x"})
        self.assertEqual(resposta.status_code, 429)  # mesmo comportamento de uma matrícula real

    def test_senha_nunca_aparece_nos_logs(self):
        with self.assertLogs("contas.seguranca", level="WARNING") as logs:
            self.client.post(self.url, {"username": "2026001", "password": "SenhaSuperSecreta"})
        texto = " ".join(logs.output)
        self.assertNotIn("SenhaSuperSecreta", texto)
        self.assertNotIn("2026001", texto)  # só o hash da matrícula é registrado


class AjudaTests(BaseTestCase):
    def test_ajuda_e_publica_e_mostra_os_limites_reais(self):
        resposta = self.client.get(reverse("contas:ajuda"))
        self.assertContains(resposta, str(settings.LOGIN_MAX_FALHAS))
        self.assertContains(resposta, str(settings.LOGIN_BLOQUEIO_SEGUNDOS // 60))
