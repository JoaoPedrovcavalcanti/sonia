from django.core.exceptions import ValidationError
from django.urls import reverse

from contas.models import Usuario
from sistema.utils_teste import BaseTestCase


class UsuarioModelTests(BaseTestCase):
    def test_matricula_e_o_username(self):
        u = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.assertEqual(u.matricula, "2026001")
        self.assertTrue(u.check_password(self.SENHA))
        self.assertNotEqual(u.password, self.SENHA)  # senha guardada com hash

    def test_matricula_rejeita_caracteres_invalidos(self):
        u = Usuario(username="maria silva!")
        with self.assertRaises(ValidationError) as ctx:
            u.full_clean(exclude=["password"])
        self.assertIn("username", ctx.exception.message_dict)

    def test_matricula_deve_ser_unica_com_mensagem_em_portugues(self):
        Usuario.objects.create_user("2026001", password=self.SENHA)
        duplicado = Usuario(username="2026001")
        with self.assertRaises(ValidationError) as ctx:
            duplicado.full_clean(exclude=["password"])
        self.assertIn("Já existe um usuário com esta matrícula.", ctx.exception.message_dict["username"])


class AdminUsuarioTests(BaseTestCase):
    def test_superusuario_cria_usuario_pelo_admin(self):
        admin = Usuario.objects.create_superuser("admin", password=self.SENHA)
        self.client.force_login(admin)
        resposta = self.client.post(
            reverse("admin:contas_usuario_add"),
            {"username": "2026777", "usable_password": "true", "password1": "OutraSenha#9876", "password2": "OutraSenha#9876"},
        )
        self.assertEqual(resposta.status_code, 302, getattr(resposta, "context", None) and resposta.context["adminform"].form.errors)
        self.assertTrue(Usuario.objects.filter(username="2026777").exists())

    def test_usuario_comum_nao_acessa_o_admin(self):
        comum = Usuario.objects.create_user("2026001", password=self.SENHA)
        self.client.force_login(comum)
        resposta = self.client.get(reverse("admin:index"))
        self.assertEqual(resposta.status_code, 302)  # manda para o login do admin
