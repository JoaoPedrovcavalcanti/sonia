from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.db import models


class Usuario(AbstractUser):
    """Usuário do sistema.

    O campo `username` do Django guarda a MATRÍCULA (é o que a tela de login
    pede). Manter o modelo próprio desde o início permite evoluir (perfil,
    cargo, unidade...) sem migração dolorosa depois.
    """

    username = models.CharField(
        "matrícula",
        max_length=30,
        unique=True,
        help_text="Até 30 caracteres: letras, números, ponto, hífen ou sublinhado.",
        validators=[
            RegexValidator(
                r"^[A-Za-z0-9._-]+$",
                "Use apenas letras, números, ponto, hífen ou sublinhado.",
            )
        ],
        error_messages={"unique": "Já existe um usuário com esta matrícula."},
    )

    class Meta:
        verbose_name = "usuário"
        verbose_name_plural = "usuários"

    @property
    def matricula(self) -> str:
        return self.username
