import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.views import LoginView, LogoutView
from django.views.generic import TemplateView

from .forms import EntrarForm

logger = logging.getLogger("contas.seguranca")


class EntrarView(LoginView):
    """Tela de login.

    - Envia por POST com token CSRF (a senha nunca vai para a URL).
    - Quem já está autenticado é redirecionado.
    - O parâmetro `next` só é aceito se apontar para este próprio site
      (o LoginView do Django valida: protege contra open redirect).
    """

    template_name = "contas/entrar.html"
    authentication_form = EntrarForm
    redirect_authenticated_user = True

    def form_valid(self, form):
        resposta = super().form_valid(form)
        logger.info("Login realizado usuario_id=%s", self.request.user.pk)
        return resposta

    def form_invalid(self, form):
        resposta = super().form_invalid(form)
        if getattr(form, "bloqueado", False):
            resposta.status_code = 429  # Too Many Requests: sinal correto p/ bots e monitoramento
        return resposta


class SairView(LogoutView):
    """Logout. O Django só aceita POST aqui: um link GET poderia deslogar o
    usuário sem querer (ex.: uma imagem maliciosa em outra página)."""

    def post(self, request, *args, **kwargs):
        usuario_id = request.user.pk
        resposta = super().post(request, *args, **kwargs)
        logger.info("Logout usuario_id=%s", usuario_id)
        messages.info(request, "Você saiu do sistema com segurança.")
        return resposta


class AjudaView(TemplateView):
    """Página pública de ajuda. Os números vêm das configurações, então o
    texto nunca contradiz o comportamento real do bloqueio."""

    template_name = "contas/ajuda.html"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["max_falhas"] = settings.LOGIN_MAX_FALHAS
        contexto["minutos_bloqueio"] = settings.LOGIN_BLOQUEIO_SEGUNDOS // 60
        return contexto
