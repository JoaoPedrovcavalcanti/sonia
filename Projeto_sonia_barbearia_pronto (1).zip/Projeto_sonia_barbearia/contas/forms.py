import logging

from django.contrib.auth.forms import (
    AdminUserCreationForm,
    AuthenticationForm,
    UserChangeForm,
)
from django.core.exceptions import ValidationError

from . import throttle
from .models import Usuario

logger = logging.getLogger("contas.seguranca")


class EntrarForm(AuthenticationForm):
    """Formulário de login com mensagens em português e proteção anti-força-bruta."""

    error_messages = {
        # Mensagem ÚNICA para matrícula inexistente e senha errada: não revela
        # quais matrículas existem.
        "invalid_login": "Matrícula ou senha incorretas. Confira os dados e tente novamente.",
        "inactive": "Esta conta está inativa. Procure a administração.",
        "bloqueado": "Muitas tentativas sem sucesso. Aguarde alguns minutos e tente novamente.",
    }

    def __init__(self, request=None, *args, **kwargs):
        super().__init__(request, *args, **kwargs)
        self.bloqueado = False
        self.fields["username"].label = "Matrícula"
        self.fields["username"].widget.attrs.update(
            {
                "autocomplete": "username",
                "autocapitalize": "none",
                "spellcheck": "false",
                "autofocus": True,
            }
        )
        self.fields["password"].label = "Senha"
        # "current-password" (e não "off") permite gerenciadores de senha.
        self.fields["password"].widget.attrs.update({"autocomplete": "current-password"})

    def clean(self):
        matricula = self.cleaned_data.get("username") or ""
        ip = throttle.ip_do_cliente(self.request)

        if matricula and throttle.bloqueado(matricula, ip):
            self.bloqueado = True
            logger.warning("Login bloqueado por excesso de falhas matricula=%s", throttle.hash_matricula(matricula))
            raise ValidationError(self.error_messages["bloqueado"], code="bloqueado")

        try:
            dados = super().clean()
        except ValidationError:
            if matricula:
                total = throttle.registrar_falha(matricula, ip)
                logger.warning("Falha de login matricula=%s total_falhas=%s", throttle.hash_matricula(matricula), total)
            raise

        throttle.limpar(matricula, ip)
        return dados


class UsuarioCriacaoForm(AdminUserCreationForm):
    """Criação de usuário no admin (o form nativo é preso ao modelo User)."""

    class Meta(AdminUserCreationForm.Meta):
        model = Usuario


class UsuarioAlteracaoForm(UserChangeForm):
    class Meta(UserChangeForm.Meta):
        model = Usuario
