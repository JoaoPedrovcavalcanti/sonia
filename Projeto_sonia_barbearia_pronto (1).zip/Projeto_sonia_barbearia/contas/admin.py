from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .forms import UsuarioAlteracaoForm, UsuarioCriacaoForm
from .models import Usuario


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    form = UsuarioAlteracaoForm
    add_form = UsuarioCriacaoForm
    list_display = ("username", "first_name", "last_name", "is_staff", "is_active", "last_login")
    list_filter = ("is_staff", "is_superuser", "is_active")
    search_fields = ("username", "first_name", "last_name", "email")
