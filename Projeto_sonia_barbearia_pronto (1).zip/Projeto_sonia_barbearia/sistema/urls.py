"""Roteamento raiz. Cada app declara as próprias rotas (contas/urls.py, barbearia/urls.py)."""

from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("contas.urls")),
    path("", include("barbearia.urls")),
]
