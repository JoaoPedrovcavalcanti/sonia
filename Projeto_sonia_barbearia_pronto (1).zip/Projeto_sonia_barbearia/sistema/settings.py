"""
Configurações do projeto Barbearia (Django 6.1).

Princípio: SEGURO POR PADRÃO. Tudo que muda entre desenvolvimento e produção
vem de variáveis de ambiente, ou do arquivo `.env` na raiz do projeto
(veja `.env.example`). Nenhum segredo fica no código-fonte.
"""

import mimetypes
import os
from pathlib import Path

from django.core.exceptions import ImproperlyConfigured
from django.utils.csp import CSP

# Garante que o navegador entenda .css/.js no Windows (o registro do sistema às
# vezes associa .css a text/plain e a página aparece sem estilo).
mimetypes.add_type("text/css", ".css", True)
mimetypes.add_type("application/javascript", ".js", True)

BASE_DIR = Path(__file__).resolve().parent.parent


# --------------------------------------------------------------------------- #
# Leitura de variáveis de ambiente (sem depender de bibliotecas externas)
# --------------------------------------------------------------------------- #
def _carregar_dotenv(caminho: Path) -> None:
    """Lê linhas CHAVE=valor de um .env simples.

    Variáveis já definidas no ambiente têm prioridade sobre o arquivo.
    """
    if not caminho.is_file():
        return
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, _, valor = linha.partition("=")
        valor = valor.split(" #", 1)[0].strip().strip("'\"")
        os.environ.setdefault(chave.strip(), valor)


def _env_bool(nome: str, padrao: bool = False) -> bool:
    valor = os.environ.get(nome)
    if valor is None:
        return padrao
    return valor.strip().lower() in {"1", "true", "yes", "sim", "on"}


def _env_lista(nome: str) -> list[str]:
    return [item.strip() for item in os.environ.get(nome, "").split(",") if item.strip()]


_carregar_dotenv(BASE_DIR / ".env")


# --------------------------------------------------------------------------- #
# Núcleo
# --------------------------------------------------------------------------- #
# Padrão FALSO: esquecer a variável em produção não liga o modo debug.
DEBUG = _env_bool("DJANGO_DEBUG", False)

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "")
if not SECRET_KEY:
    if DEBUG:
        # Chave descartável, válida só para desenvolvimento local.
        SECRET_KEY = "dev-insecure-nao-use-em-producao"  # noqa: S105
    else:
        raise ImproperlyConfigured(
            "Defina DJANGO_SECRET_KEY (ou DJANGO_DEBUG=1 para desenvolvimento). "
            "Dica: copie .env.example para .env."
        )

ALLOWED_HOSTS = _env_lista("DJANGO_ALLOWED_HOSTS") or (
    ["localhost", "127.0.0.1", "[::1]"] if DEBUG else []
)
CSRF_TRUSTED_ORIGINS = _env_lista("DJANGO_CSRF_TRUSTED_ORIGINS")


# --------------------------------------------------------------------------- #
# Aplicações e middleware
# --------------------------------------------------------------------------- #
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Apps do projeto
    "contas.apps.ContasConfig",  # autenticação e usuário
    "barbearia.apps.BarbeariaConfig",  # páginas do site e candidaturas
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.middleware.csp.ContentSecurityPolicyMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "sistema.urls"
WSGI_APPLICATION = "sistema.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]


# --------------------------------------------------------------------------- #
# Banco de dados
# --------------------------------------------------------------------------- #
# SQLite atende desenvolvimento e demonstração. Em produção com vários
# processos/servidores, troque por PostgreSQL (ver docs/ARQUITETURA.md).
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# --------------------------------------------------------------------------- #
# Autenticação
# --------------------------------------------------------------------------- #
# Modelo de usuário próprio, definido ANTES da primeira migração (o Django
# recomenda isso: trocar depois, com dados, é doloroso).
AUTH_USER_MODEL = "contas.Usuario"

LOGIN_URL = "contas:entrar"
LOGIN_REDIRECT_URL = "barbearia:inicio"
LOGOUT_REDIRECT_URL = "contas:entrar"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 10},
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Sessão curta (8 h): um posto compartilhado não fica logado para sempre.
SESSION_COOKIE_AGE = 60 * 60 * 8

# Proteção contra força bruta no login (ver contas/throttle.py).
LOGIN_MAX_FALHAS = 5
LOGIN_BLOQUEIO_SEGUNDOS = 15 * 60

# O contador de tentativas usa o cache. LocMem é por processo: suficiente para
# desenvolvimento; em produção com vários workers use um cache compartilhado.
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
        "LOCATION": "barbearia-cache",
    }
}


# --------------------------------------------------------------------------- #
# Internacionalização
# --------------------------------------------------------------------------- #
LANGUAGE_CODE = "pt-br"
TIME_ZONE = "America/Recife"
USE_I18N = True
USE_TZ = True


# --------------------------------------------------------------------------- #
# Arquivos estáticos
# --------------------------------------------------------------------------- #
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"  # destino do `collectstatic` em produção


# --------------------------------------------------------------------------- #
# Segurança
# --------------------------------------------------------------------------- #
X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"

# Content-Security-Policy (recurso nativo do Django 6): o navegador só executa
# scripts/estilos servidos pelo próprio site. Os templates não usam código
# inline, então a política pode ser estrita.
SECURE_CSP = {
    "default-src": [CSP.SELF],
    "script-src": [CSP.SELF],
    "style-src": [CSP.SELF],
    "img-src": [CSP.SELF, "data:"],
    "object-src": [CSP.NONE],
    "base-uri": [CSP.SELF],
    "form-action": [CSP.SELF],
    "frame-ancestors": [CSP.NONE],
}

if not DEBUG:
    SECURE_SSL_REDIRECT = _env_bool("DJANGO_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    # Comece com valor baixo e aumente (31536000 = 1 ano) após validar o HTTPS.
    SECURE_HSTS_SECONDS = int(os.environ.get("DJANGO_HSTS_SECONDS", "3600"))
    if _env_bool("DJANGO_BEHIND_PROXY"):
        # Só ative se um proxy reverso confiável SEMPRE define este cabeçalho.
        SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
# Regra: nunca registrar senhas nem dados pessoais (nome, e-mail, telefone).
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "padrao": {"format": "{asctime} {levelname:<8} {name}: {message}", "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "padrao"},
    },
    "loggers": {
        "contas": {"handlers": ["console"], "level": "INFO", "propagate": False},
        "barbearia": {"handlers": ["console"], "level": "INFO", "propagate": False},
        "django.security": {"handlers": ["console"], "level": "WARNING", "propagate": False},
    },
}
