"""Base compartilhada pelos testes (não é um módulo de teste em si)."""

import logging

from django.core.cache import cache
from django.test import TestCase, override_settings

# Loggers do projeto que têm handler de console (ver LOGGING em settings.py).
_LOGGERS_RUIDOSOS = ("contas", "barbearia", "django.security")


@override_settings(
    # Os testes não devem depender do ambiente (.env) de quem os executa.
    SECURE_SSL_REDIRECT=False,
    # Hash rápido SÓ nos testes: o PBKDF2 real é lento de propósito (segurança)
    # e deixaria a suíte inteira ~10x mais lenta sem testar nada a mais.
    PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"],
)
class BaseTestCase(TestCase):
    SENHA = "SenhaForte#2026"

    def setUp(self):
        super().setUp()
        cache.clear()  # zera o contador de falhas de login entre os testes
        self._silenciar_logs()

    def _silenciar_logs(self):
        """Mantém a saída dos testes limpa. `assertLogs` continua funcionando,
        pois instala o próprio handler no logger testado."""
        for nome in _LOGGERS_RUIDOSOS:
            logger = logging.getLogger(nome)
            antigos = logger.handlers[:]
            logger.handlers = [logging.NullHandler()]
            self.addCleanup(setattr, logger, "handlers", antigos)
