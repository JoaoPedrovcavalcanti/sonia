/* Melhorias progressivas: o site funciona sem JavaScript; isto só deixa melhor. */
(() => {
  "use strict";

  // 1) Mostrar/ocultar senha (o botão nasce "hidden" e só aparece com JS ativo).
  document.querySelectorAll("[data-alternar-senha]").forEach((botao) => {
    const campo = document.getElementById(botao.getAttribute("aria-controls"));
    if (!campo) return;
    botao.hidden = false;
    botao.addEventListener("click", () => {
      const mostrar = campo.type === "password";
      campo.type = mostrar ? "text" : "password";
      botao.textContent = mostrar ? "Ocultar" : "Mostrar";
      botao.setAttribute("aria-pressed", String(mostrar));
    });
  });

  // 2) Evita envio duplo (duplo clique) e dá retorno visual.
  const liberar = (form) => {
    delete form.dataset.enviando;
    const botao = form.querySelector("button[type=submit]");
    if (botao && botao.dataset.rotulo) {
      botao.textContent = botao.dataset.rotulo;
      botao.removeAttribute("aria-busy");
    }
  };
  document.querySelectorAll("form[data-evita-duplo-envio]").forEach((form) => {
    form.addEventListener("submit", (evento) => {
      if (form.dataset.enviando) {
        evento.preventDefault();
        return;
      }
      form.dataset.enviando = "1";
      const botao = form.querySelector("button[type=submit]");
      if (botao) {
        botao.dataset.rotulo = botao.textContent;
        botao.textContent = "Enviando…";
        botao.setAttribute("aria-busy", "true");
      }
    });
    // Voltar pelo histórico (bfcache) não pode deixar o botão travado.
    window.addEventListener("pageshow", () => liberar(form));
  });

  // 3) Máscara de telefone: (81) 99999-9999. O servidor valida de novo.
  document.querySelectorAll("input[inputmode=tel]").forEach((campo) => {
    campo.addEventListener("input", () => {
      const d = campo.value.replace(/\D/g, "").slice(0, 11);
      let t = d;
      if (d.length > 6) {
        const meio = d.length === 11 ? 7 : 6;
        t = `(${d.slice(0, 2)}) ${d.slice(2, meio)}-${d.slice(meio)}`;
      } else if (d.length > 2) {
        t = `(${d.slice(0, 2)}) ${d.slice(2)}`;
      } else if (d.length > 0) {
        t = `(${d}`;
      }
      campo.value = t;
    });
  });
})();
