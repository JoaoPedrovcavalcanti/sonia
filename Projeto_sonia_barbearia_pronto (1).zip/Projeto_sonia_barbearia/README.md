# Barbearia — portal com login e candidaturas

Sistema web em **Django 6.1** para uma barbearia: tela de login por matrícula, página institucional protegida e formulário **"Trabalhe conosco"** com regras de negócio, painel administrativo e testes automatizados.

> Projeto acadêmico de **Kauã Felipe Lopes Seabra** (2026).

| | |
|---|---|
| **Stack** | Python 3.12+ · Django 6.1 · SQLite · HTML/CSS/JS puros (sem frameworks de front-end) |
| **Dependências diretas** | 1 (`Django`) |
| **Testes** | 50 testes automatizados, ~0,5 s |
| **Documentação** | [Arquitetura](docs/ARQUITETURA.md) · [Auditoria (antes × depois)](docs/AUDITORIA.md) · [Roteiro de apresentação](docs/APRESENTACAO.md) |

## O que o sistema faz

| Funcionalidade | Detalhes |
|---|---|
| **Login por matrícula** | Autenticação real do Django, envio por `POST` com token CSRF, sessão de 8 h, redirecionamento seguro (`next`) |
| **Proteção contra força bruta** | 5 tentativas erradas bloqueiam a combinação matrícula + IP por 15 min (resposta HTTP 429) |
| **Páginas protegidas** | Visitante sem login é enviado ao login e volta à página pedida depois de entrar |
| **Trabalhe conosco** | Formulário validado (nome, e-mail, telefone BR, cargo, mensagem) com consentimento LGPD; uma pessoa não se candidata ao mesmo cargo duas vezes em 30 dias |
| **Painel admin** | Candidaturas com filtro, busca, mudança de situação em lote; cadastro de usuários por matrícula |
| **Ajuda** | Página pública que explica matrícula, senha e bloqueio (os números vêm das configurações) |
| **Páginas de erro** | 404, 500 e falha de CSRF personalizadas |
| **Interface** | Responsiva (testada de 320 px a desktop), acessível (contraste WCAG AA, foco visível, navegação por teclado, *skip link*), funciona sem JavaScript |

## Como executar

### Windows (PowerShell)

```powershell
cd Projeto_sonia_barbearia
py -m venv venv
.\venv\Scripts\Activate.ps1          # se bloquear: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
pip install -r requirements.txt
copy .env.example .env               # define DJANGO_DEBUG=1 para desenvolvimento
python manage.py migrate
python manage.py createsuperuser     # pergunta Matrícula (seu login), E-mail (pode ficar em branco) e Senha
python manage.py runserver
```

### Linux / macOS

```bash
cd Projeto_sonia_barbearia
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py createsuperuser     # Matrícula, E-mail (pode ficar em branco) e Senha
python manage.py runserver
```

Abra <http://127.0.0.1:8000/>. Para criar mais usuários (matrículas): <http://127.0.0.1:8000/admin/> → **Usuários** → **Adicionar**.

### Testes

```bash
python manage.py test            # 50 testes
python manage.py check --deploy  # auditoria de configuração de produção
```

## Rotas

| URL | Acesso | O que faz |
|---|---|---|
| `/entrar/` | público | Login |
| `/sair/` | logado, **somente POST** | Logout |
| `/ajuda/` | público | Ajuda para entrar |
| `/` | **login obrigatório** | Página institucional |
| `/trabalhe-conosco/` | **login obrigatório** | Formulário de candidatura |
| `/admin/` | equipe (`is_staff`) | Painel administrativo |

## Configuração (variáveis de ambiente / `.env`)

| Variável | Padrão | Para quê |
|---|---|---|
| `DJANGO_DEBUG` | `0` (desligado) | `1` só em desenvolvimento. **Seguro por padrão** |
| `DJANGO_SECRET_KEY` | — | **Obrigatória** em produção; o app recusa iniciar sem ela |
| `DJANGO_ALLOWED_HOSTS` | `localhost` (se DEBUG) | Domínios permitidos, separados por vírgula |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | — | Origens `https://…` confiáveis |
| `DJANGO_SSL_REDIRECT` | `1` (em produção) | Redireciona HTTP → HTTPS |
| `DJANGO_HSTS_SECONDS` | `3600` | Suba para `31536000` após validar o HTTPS |
| `DJANGO_BEHIND_PROXY` | `0` | `1` só atrás de proxy reverso confiável |

## Estrutura

```
Projeto_sonia_barbearia/
├── manage.py
├── requirements.txt          # só o Django (com teto de versão)
├── .env.example              # modelo de configuração (o .env real NÃO vai para o Git)
├── sistema/                  # configuração do projeto
│   ├── settings.py           #   seguro por padrão, configurado por ambiente
│   └── urls.py
├── contas/                   # autenticação
│   ├── models.py             #   Usuario (a matrícula é o login)
│   ├── forms.py              #   EntrarForm (+ anti-força-bruta)
│   ├── throttle.py           #   contador de falhas (cache)
│   ├── views.py  urls.py  admin.py
│   └── tests/
├── barbearia/                # domínio do site
│   ├── models.py             #   Candidatura (+ constraint no banco)
│   ├── forms.py              #   valida o FORMATO dos dados
│   ├── services.py           #   REGRAS de negócio (duplicidade, consentimento)
│   ├── views.py  urls.py  admin.py
│   └── tests/
├── templates/                # base, componentes, páginas de erro
└── static/                   # css, js, imagens
```

## Decisões técnicas, em resumo

- **Django com templates no servidor** (sem SPA): para duas telas e um formulário, evita uma API + front separado e herda as defesas do Django (CSRF, escape automático de HTML, sessões).
- **Modelo de usuário próprio desde o início**: o Django recomenda e é a hora mais barata de fazer (o banco ainda não tinha tabelas).
- **Camadas só onde há regra**: *view* orquestra, *form* valida formato, *service* decide regras, *model/banco* garante invariantes. Uma Clean Architecture completa seria excesso para este tamanho (veja a justificativa em [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md)).
- **CSP estrita nativa do Django 6** e **zero código inline** nos templates: um teste automatizado impede regressão.
- **Fontes do sistema**, sem Google Fonts: nenhuma requisição externa, abre offline.

## Segurança

| Ameaça | Defesa | Onde | Teste |
|---|---|---|---|
| Acesso sem login | `LoginRequiredMixin` | `barbearia/views.py` | `AcessoTests` |
| Senha exposta na URL / CSRF | `POST` + token CSRF | `entrar.html` | `LoginTests` |
| Força bruta | bloqueio por matrícula + IP, HTTP 429 | `contas/throttle.py` | `BloqueioForcaBrutaTests` |
| Enumeração de usuários | mesma mensagem para matrícula inexistente e senha errada | `contas/forms.py` | `test_mensagem_de_erro_e_igual…` |
| *Open redirect* no `next` | validação do host do Django | `EntrarView` | `test_next_externo_e_ignorado` |
| Logout forçado por link | logout só por `POST` | `SairView` | `test_logout_por_get_e_recusado` |
| XSS | escape automático + CSP sem `unsafe-inline` | templates / `settings.py` | `test_admin_escapa_html_malicioso`, `CspCompativel…` |
| Clickjacking | `X-Frame-Options: DENY` + `frame-ancestors 'none'` | `settings.py` | `CabecalhosDeSegurancaTests` |
| Segredo no código | `SECRET_KEY` por variável de ambiente | `settings.py` | `check --deploy` |
| Dado pessoal em log | logs só com IDs / hash da matrícula | `throttle.py`, `services.py` | `test_senha_nunca_aparece_nos_logs`, `test_log_da_candidatura…` |
| Candidatura sem consentimento | `CHECK` no banco (além do formulário) | `barbearia/models.py` | `RestricaoNoBancoTests` |

## Limitações conhecidas

- O contador de login usa cache em memória (`LocMem`): vale para **um** processo. Com vários *workers* use cache compartilhado (Redis ou `DatabaseCache`).
- Atrás de proxy reverso o IP do cliente depende de o proxy repassar o IP real em `REMOTE_ADDR`.
- SQLite atende desenvolvimento e demonstração; em produção com concorrência, use PostgreSQL.
- Não há recuperação de senha por e-mail (a administração redefine a senha), nem agendamento de horários.

Veja também o roteiro de evolução em [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md).

---
Desenvolvido por Kauã Felipe Lopes Seabra — 2026.
