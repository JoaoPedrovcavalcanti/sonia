@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   Enviar projeto para o GitHub
echo ============================================
echo.
echo 1) Crie um repositorio VAZIO em https://github.com/new
echo 2) Copie o link dele (ex: https://github.com/usuario/barbearia.git)
echo.
set /p URL=Cole o link aqui e aperte Enter: 
git --version >nul 2>&1 || (echo Git nao instalado. Baixe em https://git-scm.com/download/win & pause & exit /b)
if not exist .git git init
git add .
git commit -m "Primeiro commit"
git branch -M main
git remote remove origin >nul 2>&1
git remote add origin %URL%
git push -u origin main
echo.
echo Se pediu login, entre com sua conta do GitHub. Pronto!
pause
